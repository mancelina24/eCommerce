import React from "react";

const Pages = () => {
  return <div>Pages</div>;
};

export default Pages;
