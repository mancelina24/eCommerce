import React from "react";

const userContext = () => {
  return <div>userContext</div>;
};

export default userContext;
