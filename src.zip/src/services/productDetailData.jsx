import hero1 from "../assets/productDetail/hero1.png";
import hero2 from "../assets/productDetail/hero2.png";

import card1 from "../assets/productDetail/card1.png";
import card2 from "../assets/productDetail/card2.png";
import card3 from "../assets/productDetail/card3.png";
import card4 from "../assets/productDetail/card4.png";
import card5 from "../assets/productDetail/card5.png";
import card6 from "../assets/productDetail/card6.png";
import card7 from "../assets/productDetail/card7.png";
import card8 from "../assets/productDetail/card8.png";
export const heroImage = [hero1, hero2];

export const products = [
  {
    id: 1,
    image: card1,
    title: "Graphic Design",
    department: "English Department",
    oldPrice: "$16.48",
    newPrice: "$6.48",
  },
  {
    id: 2,
    image: card2,
    title: "Graphic Design",
    department: "English Department",
    oldPrice: "$16.48",
    newPrice: "$6.48",
  },
  {
    id: 3,
    image: card3,
    title: "Graphic Design",
    department: "English Department",
    oldPrice: "$16.48",
    newPrice: "$6.48",
  },
  {
    id: 4,
    image: card4,
    title: "Graphic Design",
    department: "English Department",
    oldPrice: "$16.48",
    newPrice: "$6.48",
  },
  {
    id: 5,
    image: card5,
    title: "Graphic Design",
    department: "English Department",
    oldPrice: "$16.48",
    newPrice: "$6.48",
  },
  {
    id: 6,
    image: card6,
    title: "Graphic Design",
    department: "English Department",
    oldPrice: "$16.48",
    newPrice: "$6.48",
  },
  {
    id: 7,
    image: card7,
    title: "Graphic Design",
    department: "English Department",
    oldPrice: "$16.48",
    newPrice: "$6.48",
  },
  {
    id: 8,
    image: card8,
    title: "Graphic Design",
    department: "English Department",
    oldPrice: "$16.48",
    newPrice: "$6.48",
  },
];

export const productsCard = [
  {
    id: 1,
    title: "Graphic Design",
    description: "We focus on ergonomics and meeting you...",
    price: "$16.48",
    discountPrice: "$6.48",
    rating: 4.9,
    sales: 15,
    image: "/path/to/image1.jpg", // Replace with actual image path
  },
  {
    id: 2,
    title: "Graphic Design",
    description: "We focus on ergonomics and meeting you...",
    price: "$16.48",
    discountPrice: "$6.48",
    rating: 4.9,
    sales: 15,
    image: "/path/to/image2.jpg", // Replace with actual image path
  },
];
