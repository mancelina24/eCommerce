import hero1 from "../assets/team/hero1.png";
import hero2 from "../assets/team/hero2.png";
import hero3 from "../assets/team/hero3.png";
import hero4 from "../assets/team/hero4.png";
import hero5 from "../assets/team/hero5.png";

export const heroimages = [
  hero1, // Replace with your image paths
  hero2,
  hero3,
  hero4,
  hero5,
];
